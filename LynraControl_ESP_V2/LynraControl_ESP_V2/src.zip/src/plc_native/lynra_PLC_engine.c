#include "lynra_PLC_engine.h"
#include <string.h>

typedef struct { 
bool started; 
bool prev_match; 
bool output_on; 
uint32_t trigger_count;
uint32_t completion_count;
uint64_t started_at; 
uint64_t elapsed_ms; 
uint32_t pulse_phase;
 uint32_t edge_phase_delay_ms;
 uint32_t transition_delay_ms; 
uint64_t random_due_ms; 
bool random_pending; 
bool random_target; 
bool multi_permanent; 
bool multi_cancel_press; 
bool stairway_suppress_release; 
int32_t counter_value;
bool counter_prev_cnt;
uint64_t hours_elapsed_ms;       /* Güncel çalışma süresi */
uint64_t hours_total_ms;         /* Kümülatif çalışma süresi */
uint64_t hours_last_update_ms;   /* Son güncelleme zamanı */LynraExecutionState execution_state; 
uint32_t threshold_count;
uint32_t threshold_last_count;
uint64_t threshold_window_start_ms;
bool threshold_prev_input;
 bool virtual_started;
 bool physical_taken_over;
} TimerState;
struct LynraPlcEngine {
 bool in_use, has_last_scan;
 uint64_t last_scan;
 uint32_t outputs, previous_inputs, random_state;
 size_t count;
 LynraRule rules[LYNRA_PLC_MAX_RULES];
 bool rule_prev_active[LYNRA_PLC_MAX_RULES];
  uint8_t cmd_pc[LYNRA_PLC_MAX_RULES];
  bool cmd_running[LYNRA_PLC_MAX_RULES];
  bool cmd_waiting[LYNRA_PLC_MAX_RULES];
  uint64_t cmd_wait_at[LYNRA_PLC_MAX_RULES];
  uint32_t cmd_latch_mask[LYNRA_PLC_MAX_RULES];
  uint32_t cmd_latch_values[LYNRA_PLC_MAX_RULES];
  uint32_t cmd_follow_mask[LYNRA_PLC_MAX_RULES];
 uint32_t output_control_mask;
 uint32_t output_control_values;
 TimerState timers[LYNRA_PLC_MAX_RULES][LYNRA_PLC_MAX_ACTIONS];
};
static LynraPlcEngine instance;
LynraPlcEngine *lynra_plc_create(void) {
 if (instance.in_use) return NULL;
 memset(&instance, 0, sizeof(instance)); instance.in_use = true; return &instance;
}
void lynra_plc_destroy(LynraPlcEngine *e) { if (e == &instance) memset(e, 0, sizeof(*e)); }
void lynra_plc_reset(LynraPlcEngine *e) {
 if (!e || !e->in_use) return;
 memset(e->timers, 0, sizeof(e->timers));
 for (size_t i = 0; i < e->count; ++i) {
    for (unsigned j = 0; j < e->rules[i].action_count; ++j) {
        const LynraAction *a = &e->rules[i].actions[j];

        if (a->type == LYNRA_COUNTER_UP_DOWN) {
            e->timers[i][j].counter_value =
                a->counter_start_value;
        }
    }
}
 memset(e->rule_prev_active, 0, sizeof(e->rule_prev_active));
 memset(e->cmd_pc, 0, sizeof(e->cmd_pc));
 memset(e->cmd_running, 0, sizeof(e->cmd_running));
 memset(e->cmd_waiting, 0, sizeof(e->cmd_waiting));
 memset(e->cmd_wait_at, 0, sizeof(e->cmd_wait_at));
 memset(e->cmd_latch_mask, 0, sizeof(e->cmd_latch_mask));
 memset(e->cmd_latch_values, 0, sizeof(e->cmd_latch_values));
 memset(e->cmd_follow_mask, 0, sizeof(e->cmd_follow_mask));
 e->output_control_mask = 0;
 e->output_control_values = 0;
 e->outputs = 0; e->previous_inputs = 0; e->random_state = 0x9E3779B9u; e->last_scan = 0; e->has_last_scan = false;
}
bool lynra_plc_load_rules(LynraPlcEngine *e, const LynraRule *rules, size_t count) {
 if (!e || !e->in_use || count > LYNRA_PLC_MAX_RULES || (count && !rules)) return false;
 for (size_t i = 0; i < count; ++i) {
  const LynraRule *r = &rules[i];
  if (r->run_policy > LYNRA_RUN_REPEAT ||
      !r->condition_count || r->condition_count > LYNRA_PLC_MAX_CONDITIONS ||
      !r->action_count || r->action_count > LYNRA_PLC_MAX_ACTIONS ||
      r->logic_operator > LYNRA_LOGIC_NOT) return false;
  /* Validate RPN stack shape before accepting a program. */
  if (r->expression_count > LYNRA_PLC_MAX_EXPR_TOKENS) return false;
  if (r->expression_count) {
   unsigned depth = 0;
   for (unsigned t = 0; t < r->expression_count; ++t) {
    const LynraExprToken *x = &r->expression[t];
    if (x->op == LYNRA_EXPR_CONDITION) {
     if (x->condition_index >= r->condition_count ||
         depth >= LYNRA_PLC_MAX_EXPR_TOKENS) return false;
     ++depth;
    } else if (x->op == LYNRA_EXPR_NOT) {
     if (depth < 1) return false;
    } else if (x->op == LYNRA_EXPR_AND || x->op == LYNRA_EXPR_OR ||
               x->op == LYNRA_EXPR_XOR) {
     if (depth < 2) return false;
     --depth;
    } else return false;
   }
   if (depth != 1) return false;
  }
  for (unsigned c = 0; c < r->condition_count; ++c) {
   if (r->conditions[c].input_index < 1 || r->conditions[c].input_index > LYNRA_PLC_MAX_INPUTS ||
       r->conditions[c].trigger > LYNRA_TRIGGER_FALLING) return false;
  }
   /* Command sequences cannot mix with predefined function blocks. */
   bool output_controls = r->actions[0].type >= LYNRA_OUTPUT_ON;
   bool commands = !output_controls && r->actions[0].type >= LYNRA_CMD_WAIT;
   uint32_t used_outputs = 0;
   for (unsigned a = 0; a < r->action_count; ++a) {
       const LynraAction *act = &r->actions[a];
       if (output_controls) {
           if (act->type < LYNRA_OUTPUT_ON || act->type > LYNRA_OUTPUT_TOGGLE ||
               act->output_index < 1 || act->output_index > LYNRA_PLC_MAX_OUTPUTS) return false;
           continue;
       }
       if ((act->type >= LYNRA_CMD_WAIT) != commands) return false;
       if (commands) {
           if (act->type > LYNRA_CMD_RESET) return false;
           if (act->type == LYNRA_CMD_WAIT) {
               if (act->output_index != 0) return false;
           } else {
               if (act->output_index < 1 || act->output_index > LYNRA_PLC_MAX_OUTPUTS) return false;
               uint32_t bit = 1u << (act->output_index - 1);
               if (used_outputs & bit) return false;
               used_outputs |= bit;
               if (act->type == LYNRA_CMD_FOLLOW &&
                   (act->follow_input_index < 1 || act->follow_input_index > LYNRA_PLC_MAX_INPUTS)) return false;
           }
       }
   }
   if (commands || output_controls) continue;
   for (unsigned a = 0; a < r->action_count; ++a)
    if ((r->actions[a].type != LYNRA_TIMER_ON_OFF_DELAY &&
        r->actions[a].type != LYNRA_TIMER_WIPING_RELAY &&
        r->actions[a].type != LYNRA_TIMER_EDGE_WIPING_RELAY &&
        r->actions[a].type != LYNRA_TIMER_ASYNC_PULSE &&
        r->actions[a].type != LYNRA_TIMER_RANDOM_GENERATOR &&
        r->actions[a].type != LYNRA_TIMER_STAIRWAY &&
        r->actions[a].type != LYNRA_TIMER_MULTI_FUNCTION &&
        r->actions[a].type != LYNRA_TIMER_STOPWATCH &&
				r->actions[a].type != LYNRA_COUNTER_UP_DOWN &&
				r->actions[a].type != LYNRA_COUNTER_HOURS &&
				r->actions[a].type != LYNRA_THRESHOLD_TRIGGER) ||
        r->actions[a].output_index < 1 || r->actions[a].output_index > LYNRA_PLC_MAX_OUTPUTS ||
        r->actions[a].reset_input_index > LYNRA_PLC_MAX_INPUTS ||
			  r->actions[a].direction_input_index > LYNRA_PLC_MAX_INPUTS ||
				(r->actions[a].type == LYNRA_COUNTER_UP_DOWN &&
				r->actions[a].counter_input_index == 0) ||
				(r->actions[a].type == LYNRA_THRESHOLD_TRIGGER &&
			  (r->actions[a].threshold_input_index < 1 ||
				r->actions[a].threshold_input_index > LYNRA_PLC_MAX_INPUTS ||
				r->actions[a].threshold_gate_ms < 1000 ||
				r->actions[a].threshold_gate_ms > 100000 ||
				r->actions[a].threshold_on > 9999 ||
				r->actions[a].threshold_off > 9999)) ||
			 r->actions[a].virtual_start > 1 ||
             (r->actions[a].virtual_start &&
              ((r->actions[a].type > LYNRA_TIMER_RANDOM_GENERATOR &&
               r->actions[a].type != LYNRA_TIMER_STOPWATCH))) ||
             r->actions[a].repeat > 1 ||
             (r->actions[a].type == LYNRA_TIMER_ON_OFF_DELAY &&
              r->actions[a].repeat && r->actions[a].tl_ms == 0) ||
			 r->actions[a].retrigger > 1 ||
       (r->actions[a].type == LYNRA_TIMER_STOPWATCH &&
        r->actions[a].stopwatch_time_base > 2) ||
       (r->actions[a].type == LYNRA_TIMER_STAIRWAY &&
        (r->actions[a].t_ms == 0 ||
         r->actions[a].warning_before_ms > r->actions[a].t_ms ||
         r->actions[a].warning_off_ms > r->actions[a].warning_before_ms)) ||
       (r->actions[a].type == LYNRA_TIMER_MULTI_FUNCTION &&
        (r->actions[a].t_ms == 0 || r->actions[a].tl_ms == 0 ||
         r->actions[a].warning_before_ms > r->actions[a].t_ms ||
         r->actions[a].warning_off_ms > r->actions[a].warning_before_ms)) ||
       (r->actions[a].type == LYNRA_TIMER_EDGE_WIPING_RELAY &&
        (r->actions[a].th_ms == 0 ||
				 r->actions[a].tl_ms == 0)) ||
       (r->actions[a].type == LYNRA_TIMER_ASYNC_PULSE &&
        (r->actions[a].th_ms == 0 || r->actions[a].tl_ms == 0))) return false;
 }
 if (count) memcpy(e->rules, rules, count * sizeof(*rules));
 e->count = count;
lynra_plc_reset(e);

return true;
}
/* Deterministic PRNG for repeatable PC tests and embedded behavior. */
static uint32_t random_delay(LynraPlcEngine *e, uint32_t upper_ms) {
 uint32_t x = e->random_state;
 x ^= x << 13; x ^= x >> 17; x ^= x << 5;
 e->random_state = x;
 return (uint32_t)((uint64_t)x % ((uint64_t)upper_ms + 1u));
}
static bool matches(const LynraRule *r, uint32_t inputs, uint32_t previous) {
 if (r->expression_count) {
  bool stack[LYNRA_PLC_MAX_EXPR_TOKENS];
  unsigned depth = 0;
  for (unsigned t = 0; t < r->expression_count; ++t) {
   const LynraExprToken *x = &r->expression[t];
   if (x->op == LYNRA_EXPR_CONDITION) {
    const LynraCondition *cond = &r->conditions[x->condition_index];
    uint32_t bit = 1u << (cond->input_index - 1);
    bool now = (inputs & bit) != 0;
    bool before = (previous & bit) != 0;
    stack[depth++] = cond->trigger == LYNRA_TRIGGER_HIGH ? now :
       cond->trigger == LYNRA_TRIGGER_LOW ? !now :
       cond->trigger == LYNRA_TRIGGER_RISING ? now && !before : !now && before;
   } else if (x->op == LYNRA_EXPR_NOT) {
    stack[depth - 1] = !stack[depth - 1];
   } else {
    bool rhs = stack[--depth];
    bool lhs = stack[depth - 1];
    stack[depth - 1] = x->op == LYNRA_EXPR_AND ? lhs && rhs :
                       x->op == LYNRA_EXPR_OR ? lhs || rhs : lhs != rhs;
   }
  }
  return stack[0];
 }
 unsigned matched = 0, previous_matched = 0;
 for (unsigned i = 0; i < r->condition_count; ++i) {
  const LynraCondition *c = &r->conditions[i];
  uint32_t bit = 1u << (c->input_index - 1);
  bool now = (inputs & bit) != 0, before = (previous & bit) != 0;
  bool yes = c->trigger == LYNRA_TRIGGER_HIGH ? now :
             c->trigger == LYNRA_TRIGGER_LOW ? !now :
             c->trigger == LYNRA_TRIGGER_RISING ? now && !before : !now && before;
  matched += yes;
  /* Edge evaluation compares the same logical conditions across scans. */
  bool prior_yes = c->trigger == LYNRA_TRIGGER_HIGH ? before :
                   c->trigger == LYNRA_TRIGGER_LOW ? !before : false;
  previous_matched += prior_yes;
 }
 switch (r->logic_operator) {
  case LYNRA_LOGIC_AND: return matched == r->condition_count;
  case LYNRA_LOGIC_AND_EDGE: return matched == r->condition_count && previous_matched != r->condition_count;
  case LYNRA_LOGIC_OR: return matched != 0;
  case LYNRA_LOGIC_XOR: return (matched & 1u) != 0;
  case LYNRA_LOGIC_NAND: return matched != r->condition_count;
  case LYNRA_LOGIC_NAND_EDGE: return matched != r->condition_count && previous_matched == r->condition_count;
  case LYNRA_LOGIC_NOR: case LYNRA_LOGIC_NOT: return matched == 0;
  default: return false;
 }
}
bool lynra_plc_scan(LynraPlcEngine *e, uint64_t now_ms, uint32_t inputs) {
 if (!e || !e->in_use || (e->has_last_scan && now_ms < e->last_scan)) return false;
 uint32_t result = e->output_control_values & e->output_control_mask;
 for (size_t i = 0; i < e->count; ++i) {
  const LynraRule *r = &e->rules[i];
  bool active = matches(r, inputs, e->previous_inputs);
  /* A trigger is a rule-level event, shared by all actions. */
  bool trigger_event = active && !e->rule_prev_active[i];
  e->rule_prev_active[i] = active;

   if (r->actions[0].type >= LYNRA_OUTPUT_ON) {
       for (unsigned j = 0; j < r->action_count; ++j) {
           const LynraAction *a = &r->actions[j];
           uint32_t bit = 1u << (a->output_index - 1);
           bool execute = (a->type == LYNRA_OUTPUT_ON || a->type == LYNRA_OUTPUT_OFF || trigger_event);
           if (!execute) continue;
           bool value = false;
           if (a->type == LYNRA_OUTPUT_ON) value = active;
           else if (a->type == LYNRA_OUTPUT_OFF) value = !active;
           else if (a->type == LYNRA_OUTPUT_SET) value = true;
           else if (a->type == LYNRA_OUTPUT_RESET) value = false;
           else value = (result & bit) == 0;
           e->output_control_mask |= bit;
           if (value) { result |= bit; e->output_control_values |= bit; }
           else { result &= ~bit; e->output_control_values &= ~bit; }
       }
       continue;
   }
   if (r->actions[0].type >= LYNRA_CMD_WAIT) {
       if (trigger_event && (!e->cmd_running[i] || r->run_policy == LYNRA_RUN_REPEAT)) {
           e->cmd_pc[i] = 0;
           e->cmd_running[i] = true;
           e->cmd_waiting[i] = false;
           e->cmd_follow_mask[i] = 0;
       }
       /* Execute immediate commands in one scan; WAIT yields to the next scan. */
       while (e->cmd_running[i] && e->cmd_pc[i] < r->action_count) {
           const LynraAction *a = &r->actions[e->cmd_pc[i]];
           if (a->type == LYNRA_CMD_WAIT) {
               if (!e->cmd_waiting[i]) {
                   e->cmd_waiting[i] = true;
                   e->cmd_wait_at[i] = now_ms;
               }
               if (now_ms - e->cmd_wait_at[i] < a->t_ms) break;
               e->cmd_waiting[i] = false;
           } else {
               uint32_t bit = 1u << (a->output_index - 1);
               if (a->type == LYNRA_CMD_FOLLOW) {
                   e->cmd_follow_mask[i] |= bit;
               } else {
                   e->cmd_latch_mask[i] |= bit;
                   if (a->type == LYNRA_CMD_SET) e->cmd_latch_values[i] |= bit;
                   else e->cmd_latch_values[i] &= ~bit;
               }
           }
           e->cmd_pc[i]++;
       }
       if (e->cmd_pc[i] >= r->action_count) e->cmd_running[i] = false;
  /* Command output arbitration: later command rules take precedence. */
      uint32_t mask = e->cmd_latch_mask[i];
      uint32_t bits = e->cmd_latch_values[i];
      for (unsigned j = 0; j < e->rules[i].action_count; ++j) {
          const LynraAction *a = &e->rules[i].actions[j];
          if (a->type != LYNRA_CMD_FOLLOW) continue;
          uint32_t bit = 1u << (a->output_index - 1);
          if (!(e->cmd_follow_mask[i] & bit)) continue;
          mask |= bit;
          if (inputs & (1u << (a->follow_input_index - 1))) bits |= bit;
          else bits &= ~bit;
      }
      result = (result & ~mask) | (bits & mask);

       continue;
   }
  bool rule_accept_trigger = trigger_event;
  for (unsigned j = 0; j < r->action_count; ++j) {
   const LynraAction *a = &r->actions[j];
   TimerState *s = &e->timers[i][j];
   bool on = false;
   /* Rule-level trigger admission, separate from timer output state.
      A new activation is accepted when idle, or while running in REPEAT.
      LEVEL conditions generate a new event only after deactivation. */
     /* ON/OFF delay RESET has priority over virtual and physical triggers.
        A reset permanently consumes the one-shot virtual startup until
        the engine/program is reset, while physical inputs remain usable. */
     if (a->type == LYNRA_TIMER_ON_OFF_DELAY &&
         a->reset_input_index != 0 &&
         (inputs & (1u << (a->reset_input_index - 1))) != 0) {
         memset(s, 0, sizeof(*s));
         s->virtual_started = true;
         s->physical_taken_over = true;
         s->execution_state = LYNRA_EXEC_IDLE;
         continue;
     }
     /* Virtual startup applies only to supported timer types. */
     const bool physical_active = active;
     const bool virtual_enabled = a->virtual_start &&
         (a->type == LYNRA_TIMER_ON_OFF_DELAY ||
          (a->type >= LYNRA_TIMER_WIPING_RELAY &&
           a->type <= LYNRA_TIMER_RANDOM_GENERATOR));
     bool virtual_event = false;
     if (virtual_enabled && !s->physical_taken_over) {
         if (physical_active) {
             memset(s, 0, sizeof(*s));
             s->virtual_started = true;
             s->physical_taken_over = true;
             virtual_event = true;
         } else if (!s->virtual_started) {
             s->virtual_started = true;
             virtual_event = true;
         }
     }
     bool active = physical_active ||
         (virtual_enabled && !s->physical_taken_over);
     bool trigger_event = rule_accept_trigger || virtual_event;
 bool reset_rising = false;

if (a->reset_input_index != 0) {
    uint32_t mask = 1u << (a->reset_input_index - 1);

    reset_rising =
        (inputs & mask) != 0 &&
        (e->previous_inputs & mask) == 0;
}
   if (a->type == LYNRA_TIMER_ON_OFF_DELAY && r->condition_count == 1 &&
       (r->conditions[0].trigger == LYNRA_TRIGGER_RISING ||
        r->conditions[0].trigger == LYNRA_TRIGGER_FALLING)) {
    /* EDGE: wait TH, ON for TA (stored in tl_ms). TA=0 holds ON until reset. */
     if (trigger_event &&
         ((!s->started && !s->output_on) ||
          (a->retrigger && s->started && !s->output_on && s->pulse_phase == 0) ||
          (!a->repeat && !a->retrigger && s->output_on))) {
       /* Retrigger ON: restart TH only while waiting (Q OFF).
          Retrigger OFF: ignore while waiting; restart after Q turns ON. */
      s->started = true;
      s->started_at = now_ms;
      s->pulse_phase = 0;
       s->output_on = false;
      s->execution_state = LYNRA_EXEC_RUNNING;
    }
    /* Catch up over elapsed TH/TA boundaries, including sparse scans. */
    unsigned phase_guard = 0;
    while (s->started && phase_guard++ < 1024) {
      if (s->pulse_phase == 0) {
        if (now_ms - s->started_at < a->th_ms) break;
        s->started_at += a->th_ms;
        s->pulse_phase = 1;
        s->output_on = true;
        if (a->tl_ms == 0) {
          s->started = false;
          s->execution_state = LYNRA_EXEC_COMPLETED;
          break;
        }
      } else {
        if (now_ms - s->started_at < a->tl_ms) break;
        s->started_at += a->tl_ms;
        s->output_on = false;
        if (a->repeat) {
          s->pulse_phase = 0;
          s->execution_state = LYNRA_EXEC_RUNNING;
        } else {
          s->started = false;
          s->execution_state = LYNRA_EXEC_COMPLETED;
        }
      }
    }
    on = s->output_on;
   }
   else if (a->type == LYNRA_TIMER_ON_OFF_DELAY) {
    // Each input transition restarts its own delay; opposite transitions cancel it.
    if (active != s->prev_match || !s->started) {
     s->started = true;
     s->started_at = now_ms;
     uint32_t upper = active ? a->th_ms : a->tl_ms;
      bool random_mode = active ? a->th_random != 0 : a->tl_random != 0;
      s->transition_delay_ms = random_mode ? random_delay(e, upper) : upper;
    }
    uint32_t delay = s->transition_delay_ms;
    if (now_ms - s->started_at >= delay) s->output_on = active;
    on = s->output_on;
    s->execution_state = now_ms - s->started_at >= delay ?
      LYNRA_EXEC_COMPLETED : LYNRA_EXEC_RUNNING;
   }
   if (a->type == LYNRA_TIMER_WIPING_RELAY) {
    // Rising edge starts one pulse; a falling edge ends it immediately.
    // Holding the trigger HIGH cannot restart an expired pulse.
    if (!active) {
     s->started = false;
     s->output_on = false;
    } else if (!s->prev_match) {
     s->started = true;
     s->started_at = now_ms;
     s->output_on = true;
    }
    if (s->started && now_ms - s->started_at >= a->t_ms) {
     s->started = false;
     s->output_on = false;
    }
    on = s->output_on;
    if (s->started) s->execution_state = LYNRA_EXEC_RUNNING;
    else if (!active) s->execution_state = LYNRA_EXEC_IDLE;
    else if (s->execution_state == LYNRA_EXEC_RUNNING)
     s->execution_state = LYNRA_EXEC_COMPLETED;
   }
   if (a->type == LYNRA_TIMER_EDGE_WIPING_RELAY) {
    /* Phase 0 = TL (OFF), phase 1 = TH (ON). Each phase draws once. */
    if (reset_rising) {
     s->started = false;
     s->output_on = false;
     s->execution_state = LYNRA_EXEC_IDLE;
    } else if (trigger_event && (!s->started || a->retrigger)) {
     s->started = true;
     s->started_at = now_ms;
     s->pulse_phase = 0; /* number of completed ON pulses */
     s->output_on = false;
     s->edge_phase_delay_ms = a->tl_random ? random_delay(e, a->tl_ms) : a->tl_ms;
     s->execution_state = LYNRA_EXEC_RUNNING;
    }
    if (s->started) {
     /* Catch up on scans that skip phase boundaries. Zero-length random
        phases are processed immediately; the finite guard prevents a
        pathological infinite loop for N=0 with repeated zero draws. */
     unsigned guard = 0;
     while (s->started && now_ms - s->started_at >= s->edge_phase_delay_ms && guard++ < 1024) {
      s->started_at += s->edge_phase_delay_ms;
      if (!s->output_on) {
       s->output_on = true;
       s->edge_phase_delay_ms = a->th_random ? random_delay(e, a->th_ms) : a->th_ms;
      } else {
       s->pulse_phase++;
       if (a->n != 0 && s->pulse_phase >= a->n) {
        if (a->repeat) {
         s->pulse_phase = 0;
        } else {
         s->started = false;
         s->execution_state = LYNRA_EXEC_COMPLETED;
         s->output_on = false;
         break;
        }
       }
       s->output_on = false;
       s->edge_phase_delay_ms = a->tl_random ? random_delay(e, a->tl_ms) : a->tl_ms;
      }
     }
     /* If random zero-duration phases exceed the guard, defer the rest
        until the next scan to keep the scan bounded. */
     if (s->started) s->execution_state = LYNRA_EXEC_RUNNING;
    }
    on = s->started && s->output_on;
   }
   if (a->type == LYNRA_TIMER_ASYNC_PULSE) {
    // En HIGH: start with an ON phase, then repeat TH ON / TL OFF.
    // En LOW: stop immediately; the next activation starts a fresh ON phase.
    if (!active) {
     s->started = false;
     on = false;
    } else {
     if (!s->started) {
      s->started = true;
      s->started_at = now_ms;
     }
     uint64_t elapsed = now_ms - s->started_at;
     uint64_t period = (uint64_t)a->th_ms + a->tl_ms;
     on = (elapsed % period) < a->th_ms;
    }
    s->execution_state = active ? LYNRA_EXEC_RUNNING : LYNRA_EXEC_IDLE;
   }
   if (a->type == LYNRA_TIMER_RANDOM_GENERATOR) {
    // LOGO random generator: each En transition is delayed randomly.
    // TH bounds ON delay; TL bounds OFF delay. Not a free-running oscillator.
    if (active != s->prev_match) {
     s->random_pending = true;
     s->random_target = active;
     uint32_t upper = active ? a->th_ms : a->tl_ms;
     uint64_t delay = random_delay(e, upper);
     s->random_due_ms = UINT64_MAX - now_ms < delay ? UINT64_MAX : now_ms + delay;
    }
    // Reversing En before expiry cancels the old transition.
    if (s->random_pending && now_ms >= s->random_due_ms) {
     s->output_on = s->random_target;
     s->random_pending = false;
    }
    on = s->output_on;
    s->execution_state = s->random_pending ? LYNRA_EXEC_RUNNING :
      s->execution_state == LYNRA_EXEC_RUNNING || active != s->prev_match ||
      s->execution_state == LYNRA_EXEC_COMPLETED ? LYNRA_EXEC_COMPLETED : LYNRA_EXEC_IDLE;
   }
   if (a->type == LYNRA_TIMER_STAIRWAY) {
    // LOGO stairway: rising Trg sets Q; falling Trg starts countdown T.
    // A new rising edge while timing retriggers the stairway cycle.
    if (reset_rising) {
    s->started = false;
    s->output_on = false;
    s->stairway_suppress_release = false;
    s->execution_state = LYNRA_EXEC_IDLE;
}
		
		if (!reset_rising && active && !s->prev_match) {
    if (!s->output_on || !s->started || a->retrigger) {
      s->output_on = true;
      s->started = false;
      s->stairway_suppress_release = false;
     } else {
      // ONCE: ignored press must not restart the countdown on release.
      s->stairway_suppress_release = true;
     }
    }
    if (!reset_rising && !active && s->prev_match) {
     if (s->stairway_suppress_release) {
      s->stairway_suppress_release = false;
     } else if (s->output_on) {
      s->started = true;
      s->started_at = now_ms;
     }
    }
    on = s->output_on;
    if (s->started && !reset_rising) {
     uint64_t elapsed = now_ms - s->started_at;
     if (elapsed >= a->t_ms) {
    s->started = false;
    s->output_on = false;
    on = false;
}else if (a->warning_before_ms && a->warning_off_ms) {
      uint64_t warning_start = (uint64_t)a->t_ms - a->warning_before_ms;
      if (elapsed >= warning_start &&
          elapsed < warning_start + a->warning_off_ms)
       on = false;
     }
    }
    s->execution_state = s->started ? LYNRA_EXEC_RUNNING :
      s->output_on ? LYNRA_EXEC_RUNNING :
      s->execution_state == LYNRA_EXEC_RUNNING ? LYNRA_EXEC_COMPLETED : LYNRA_EXEC_IDLE;
   }
   if (a->type == LYNRA_TIMER_MULTI_FUNCTION) {
    // Short press: timed output, T begins on release.
    // Long press (TL): permanent ON. Next press switches OFF.
    bool rising = active && !s->prev_match;
    bool falling = !active && s->prev_match;
    if (rising) {
				if (s->output_on) {
						s->multi_cancel_press = true;
				} else {
						s->output_on = true;
						s->started = false;
						s->multi_permanent = false;
						s->multi_cancel_press = false;
						s->started_at = now_ms;
				}
		}
    if (active && s->output_on && !s->multi_cancel_press &&
						now_ms - s->started_at >= a->tl_ms && !s->started)
				 s->multi_permanent = true;
				if (falling) {
				if (s->multi_cancel_press) {
						s->output_on = false;
						s->started = false;
						s->multi_permanent = false;
						s->multi_cancel_press = false;
				} else if (s->output_on && !s->multi_permanent) {
						if (now_ms - s->started_at >= a->tl_ms) {
								s->multi_permanent = true;
						} else {
								s->started = true;
								s->started_at = now_ms;
						}
				}
		}
    on = s->output_on;
    if (s->started && s->output_on) {
     uint64_t elapsed = now_ms - s->started_at;
     if (elapsed >= a->t_ms) {
      s->started = false; s->output_on = false; on = false;
     } else if (a->warning_before_ms && a->warning_off_ms) {
      uint64_t warning_start = (uint64_t)a->t_ms - a->warning_before_ms;
      if (elapsed >= warning_start && elapsed < warning_start + a->warning_off_ms)
       on = false;
     }
    }
    s->execution_state = s->started ? LYNRA_EXEC_RUNNING :
      s->output_on ? (s->multi_permanent ? LYNRA_EXEC_COMPLETED : LYNRA_EXEC_RUNNING) :
      s->execution_state == LYNRA_EXEC_RUNNING ? LYNRA_EXEC_COMPLETED : LYNRA_EXEC_IDLE;
   }
      if (a->type == LYNRA_TIMER_STOPWATCH) {
     /* Virtual EN starts on the first scan. First physical EN takes over
        with a fresh elapsed time; subsequent EN cycles retain pause/resume. */
     if (a->virtual_start && !s->physical_taken_over) {
         if (physical_active) {
             s->physical_taken_over = true;
             s->virtual_started = true;
             s->started = false;
             s->elapsed_ms = 0;
             s->output_on = false;
         } else if (!s->virtual_started) {
             s->virtual_started = true;
         }
     }
     const bool stopwatch_en = physical_active ||
         (a->virtual_start && s->virtual_started && !s->physical_taken_over);
    bool reset = a->reset_input_index &&
        (inputs & (1u << (a->reset_input_index - 1))) != 0;

    if (reset) {
        s->started = false;
        s->elapsed_ms = 0;
        s->output_on = false;
    } else {
        if (stopwatch_en) {
            if (!s->started) {
                s->started = true;
                s->started_at = now_ms;
            }
        } else if (s->started) {
            uint64_t delta = now_ms - s->started_at;
            s->elapsed_ms =
                UINT64_MAX - s->elapsed_ms < delta
                    ? UINT64_MAX
                    : s->elapsed_ms + delta;
            s->started = false;
        }

        uint64_t total = s->elapsed_ms;

        if (s->started) {
            uint64_t delta = now_ms - s->started_at;
            total = UINT64_MAX - total < delta
                ? UINT64_MAX
                : total + delta;
        }

        if (total >= a->t_ms)
            s->output_on = true;
    }

    on = s->output_on;

    s->execution_state = s->output_on
        ? LYNRA_EXEC_COMPLETED
        : (s->started || s->elapsed_ms > 0)
            ? LYNRA_EXEC_RUNNING
            : LYNRA_EXEC_IDLE;
}
   if (a->type == LYNRA_COUNTER_UP_DOWN) {
    uint32_t cnt_mask = 1u << (a->counter_input_index - 1);
    bool cnt = (inputs & cnt_mask) != 0;

    bool reset = a->reset_input_index != 0 &&
        (inputs & (1u << (a->reset_input_index - 1))) != 0;

    if (reset) {
        s->counter_value = a->counter_start_value;
        s->output_on = false;
    } else if (cnt && !s->counter_prev_cnt) {
        bool down = a->direction_input_index != 0 &&
            (inputs & (1u << (a->direction_input_index - 1))) != 0;

        if (down) {
            if (s->counter_value > INT32_MIN)
                s->counter_value--;
        } else {
            if (s->counter_value < INT32_MAX)
                s->counter_value++;
        }
    }

    if (!reset) {
    if (a->counter_on >= a->counter_off) {
        if (s->counter_value >= a->counter_on)
            s->output_on = true;
        else if (s->counter_value <= a->counter_off)
            s->output_on = false;
    } else {
        if (s->counter_value <= a->counter_on)
            s->output_on = true;
        else if (s->counter_value >= a->counter_off)
            s->output_on = false;
    }
}

    s->counter_prev_cnt = cnt;
    on = s->output_on;

    s->execution_state = on
        ? LYNRA_EXEC_COMPLETED
        : LYNRA_EXEC_IDLE;
}
if (a->type == LYNRA_COUNTER_HOURS) {
    bool en = a->hours_enable_input_index != 0 &&
        (inputs & (1u << (a->hours_enable_input_index - 1))) != 0;

    bool reset = a->reset_input_index != 0 &&
        (inputs & (1u << (a->reset_input_index - 1))) != 0;

    bool reset_all = a->hours_reset_all_input_index != 0 &&
        (inputs & (1u << (a->hours_reset_all_input_index - 1))) != 0;

    uint64_t delta = e->has_last_scan
        ? now_ms - e->last_scan : 0;

    if (reset_all) {
        s->hours_elapsed_ms = 0;
        s->hours_total_ms = 0;
        s->output_on = false;
    } else {
        bool previous_en = a->hours_enable_input_index != 0 &&
    (e->previous_inputs &
     (1u << (a->hours_enable_input_index - 1))) != 0;

if (en && previous_en) {
    if (!reset) {
        s->hours_elapsed_ms =
            UINT64_MAX - s->hours_elapsed_ms < delta
                ? UINT64_MAX : s->hours_elapsed_ms + delta;
    }

    s->hours_total_ms =
        UINT64_MAX - s->hours_total_ms < delta
            ? UINT64_MAX : s->hours_total_ms + delta;
}

        if (reset) {
            s->hours_elapsed_ms = 0;
            s->output_on = false;
        } else if (s->hours_elapsed_ms >= a->hours_target_ms) {
            s->output_on = true;
        }
    }

    on = s->output_on;

    s->execution_state = on
        ? LYNRA_EXEC_COMPLETED
        : en ? LYNRA_EXEC_RUNNING : LYNRA_EXEC_IDLE;
}
	 if (a->type == LYNRA_THRESHOLD_TRIGGER) {
    uint32_t mask = 1u << (a->threshold_input_index - 1);
    bool fre = (inputs & mask) != 0;

    uint64_t gate_ms = a->threshold_gate_ms;

    if (!s->started) {
        s->started = true;
        s->threshold_window_start_ms += now_ms;
    }

    // Yalnızca yükselen kenarları say.
    if (fre && !s->threshold_prev_input) {
        if (s->threshold_count < UINT32_MAX)
            s->threshold_count++;
    }
    s->threshold_prev_input = fre;

    // Ölçüm penceresi tamamlandı.
    if (now_ms - s->threshold_window_start_ms >= gate_ms) {
			// Birden fazla ölçüm penceresi kaçırılmışsa
// ölçümü geçersiz say, Q durumunu koru.
if (now_ms - s->threshold_window_start_ms >= 2 * gate_ms) {
    s->threshold_count = 0;
    s->threshold_last_count = 0;
    s->threshold_window_start_ms = now_ms;
    s->threshold_prev_input = fre;

    on = s->output_on;
    s->execution_state = on
        ? LYNRA_EXEC_COMPLETED
        : LYNRA_EXEC_RUNNING;

    goto threshold_done;
}
        uint32_t fa = s->threshold_count;
        s->threshold_last_count = fa;
        s->threshold_count = 0;
        s->threshold_window_start_ms = now_ms;

        if (a->threshold_on >= a->threshold_off) {
            // Histerezisli kontrol
            if (fa > a->threshold_on)
                s->output_on = true;
            else if (fa <= a->threshold_off)
                s->output_on = false;
        } else {
            // Frekans aralığı kontrolü
            s->output_on =
                fa >= a->threshold_on &&
                fa < a->threshold_off;
        }
				threshold_done:;
    }

    on = s->output_on;

    s->execution_state = on
        ? LYNRA_EXEC_COMPLETED
        : LYNRA_EXEC_RUNNING;
}
	 if (on) result |= 1u << (a->output_index - 1);
   s->prev_match = active;
  }
 }
 e->outputs = result; e->previous_inputs = inputs; e->last_scan = now_ms; e->has_last_scan = true;
 return true;
}
size_t lynra_plc_get_rule_count(const LynraPlcEngine *e)
{
    return e && e->in_use ? e->count : 0;
}
bool lynra_plc_get_action_info(
    const LynraPlcEngine *e,
    size_t rule_index,
    size_t action_index,
    LynraActionType *type,
    size_t *action_count)
{
    if (!e || !e->in_use || rule_index >= e->count)
        return false;

    const LynraRule *r = &e->rules[rule_index];

    if (action_count)
        *action_count = r->action_count;

    if (type) {
        if (action_index >= r->action_count)
            return false;

        *type = r->actions[action_index].type;
    }

    return true;
}
uint32_t lynra_plc_get_inputs(const LynraPlcEngine *e)
{
    return e && e->in_use ? e->previous_inputs : 0;
}
uint32_t lynra_plc_get_outputs(const LynraPlcEngine *e) { return e && e->in_use ? e->outputs : 0; }

bool lynra_plc_get_stopwatch(const LynraPlcEngine *e, size_t rule_index,
                            size_t action_index, uint64_t *value) {
 if (!e || !e->in_use || !value || rule_index >= e->count) return false;
 const LynraRule *r = &e->rules[rule_index];
 if (action_index >= r->action_count) return false;
 const LynraAction *a = &r->actions[action_index];
 if (a->type != LYNRA_TIMER_STOPWATCH) return false;
 const TimerState *s = &e->timers[rule_index][action_index];
 uint64_t elapsed = s->elapsed_ms;
 if (s->started && e->has_last_scan) {
  uint64_t delta = e->last_scan - s->started_at;
  elapsed = UINT64_MAX - elapsed < delta ? UINT64_MAX : elapsed + delta;
 }
 uint64_t divisor = a->stopwatch_time_base == 0 ? 1u :
                    a->stopwatch_time_base == 1 ? 1000u : 60000u;
 *value = elapsed / divisor;
 return true;
}

/* Lifecycle support is added per timer type after its semantics are tested. */
bool lynra_plc_get_action_state(const LynraPlcEngine *e, size_t rule_index,
                                size_t action_index, LynraExecutionState *state) {
 if (!e || !e->in_use || !state || rule_index >= e->count) return false;
 const LynraRule *r = &e->rules[rule_index];
 if (action_index >= r->action_count) return false;
 LynraActionType type = r->actions[action_index].type;
 if (type >= LYNRA_CMD_WAIT && type <= LYNRA_CMD_RESET) {
     *state = e->cmd_running[rule_index] ? LYNRA_EXEC_RUNNING :
         e->cmd_pc[rule_index] >= r->action_count ? LYNRA_EXEC_COMPLETED : LYNRA_EXEC_IDLE;
     return true;
 }
 if (type != LYNRA_TIMER_STAIRWAY &&
     type != LYNRA_TIMER_MULTI_FUNCTION &&
     type != LYNRA_TIMER_STOPWATCH &&
     type != LYNRA_TIMER_RANDOM_GENERATOR &&
     type != LYNRA_TIMER_ON_OFF_DELAY &&
     type != LYNRA_TIMER_EDGE_WIPING_RELAY &&
     type != LYNRA_TIMER_WIPING_RELAY &&
     type != LYNRA_TIMER_ASYNC_PULSE) return false;
 *state = e->timers[rule_index][action_index].execution_state;
 return true;
}
bool lynra_plc_get_rule_state(const LynraPlcEngine *e, size_t rule_index,
                              LynraExecutionState *state) {
 if (!e || !e->in_use || !state || rule_index >= e->count) return false;
 const LynraRule *r = &e->rules[rule_index];
 bool any_running = false, any_completed = false;
 for (unsigned j = 0; j < r->action_count; ++j) {
  LynraExecutionState current;
  if (!lynra_plc_get_action_state(e, rule_index, j, &current)) return false;
  if (current == LYNRA_EXEC_RUNNING) any_running = true;
  if (current == LYNRA_EXEC_COMPLETED) any_completed = true;
 }
 *state = any_running ? LYNRA_EXEC_RUNNING :
          any_completed ? LYNRA_EXEC_COMPLETED : LYNRA_EXEC_IDLE;
 return true;
}
bool lynra_plc_get_counter(
    const LynraPlcEngine *e,
    size_t rule_index,
    size_t action_index,
    int32_t *value)
{
    if (!e || !e->in_use || !value ||
        rule_index >= e->count)
        return false;

    const LynraRule *r = &e->rules[rule_index];

    if (action_index >= r->action_count)
        return false;

    if (r->actions[action_index].type !=
        LYNRA_COUNTER_UP_DOWN)
        return false;

    *value = e->timers[rule_index][action_index].counter_value;
    return true;
}
bool lynra_plc_get_hours(
    const LynraPlcEngine *e,
    size_t rule_index,
    size_t action_index,
    uint64_t *elapsed_ms,
    uint64_t *total_ms)
{
    if (!e || !e->in_use || !elapsed_ms || !total_ms ||
        rule_index >= e->count)
        return false;

    const LynraRule *r = &e->rules[rule_index];

    if (action_index >= r->action_count ||
        r->actions[action_index].type != LYNRA_COUNTER_HOURS)
        return false;

    const TimerState *s = &e->timers[rule_index][action_index];

    *elapsed_ms = s->hours_elapsed_ms;
    *total_ms = s->hours_total_ms;

    return true;
}
bool lynra_plc_get_threshold(
    const LynraPlcEngine *e,
    size_t rule_index,
    size_t action_index,
    uint32_t *pulse_count)
{
    if (!e || !e->in_use || !pulse_count ||
        rule_index >= e->count)
        return false;

    const LynraRule *r = &e->rules[rule_index];

    if (action_index >= r->action_count ||
        r->actions[action_index].type != LYNRA_THRESHOLD_TRIGGER)
        return false;

    *pulse_count =
        e->timers[rule_index][action_index].threshold_last_count;

    return true;
}
/* Diagnostic fields: transport-independent and read-only until explicitly written. */
static LynraFieldValue diag_u64(uint64_t n) {
    return n > INT64_MAX ? INT64_MAX : (LynraFieldValue)n;
}
#define DIAG_ADD(out, field, val) do { \
    if ((out)->count >= LYNRA_MAX_PARAMETERS) return false; \
    (out)->items[(out)->count++] = (LynraParameter){LYNRA_FIELD_##field, (LynraFieldValue)(val)}; \
} while (0)

bool lynra_plc_get_parameters(const LynraPlcEngine *e, size_t ri, size_t ai,
                              LynraParameters *parameters) {
    if (!e || !e->in_use || !parameters || ri >= e->count ||
        ai >= e->rules[ri].action_count) return false;
    const LynraAction *a = &e->rules[ri].actions[ai];
    parameters->count = 0;
    switch (a->type) {
    case LYNRA_TIMER_ON_OFF_DELAY:
        DIAG_ADD(parameters, REPEAT, a->repeat);
        DIAG_ADD(parameters, RETRIGGER, a->retrigger);
        DIAG_ADD(parameters, TH_MS, a->th_ms);
        DIAG_ADD(parameters, TL_MS, a->tl_ms);
        DIAG_ADD(parameters, TH_RANDOM, a->th_random);
        DIAG_ADD(parameters, TL_RANDOM, a->tl_random);
        return true;
    case LYNRA_TIMER_WIPING_RELAY:
        DIAG_ADD(parameters, TON_MS, a->t_ms);
        DIAG_ADD(parameters, VIRTUAL_START, a->virtual_start);
        return true;
    case LYNRA_TIMER_EDGE_WIPING_RELAY:
        DIAG_ADD(parameters, TH_MS, a->th_ms);
        DIAG_ADD(parameters, TL_MS, a->tl_ms);
        DIAG_ADD(parameters, PULSE_COUNT, a->n);
        DIAG_ADD(parameters, TH_RANDOM, a->th_random);
        DIAG_ADD(parameters, TL_RANDOM, a->tl_random);
        DIAG_ADD(parameters, RESET_INPUT_INDEX, a->reset_input_index);
        DIAG_ADD(parameters, REPEAT, a->repeat);
        DIAG_ADD(parameters, RETRIGGER, a->retrigger);
        DIAG_ADD(parameters, VIRTUAL_START, a->virtual_start);
        return true;
    case LYNRA_TIMER_ASYNC_PULSE:
        DIAG_ADD(parameters, TH_MS, a->th_ms);
        DIAG_ADD(parameters, TL_MS, a->tl_ms);
        DIAG_ADD(parameters, VIRTUAL_START, a->virtual_start);
        return true;
    case LYNRA_TIMER_RANDOM_GENERATOR:
        DIAG_ADD(parameters, TH_MS, a->th_ms);
        DIAG_ADD(parameters, TL_MS, a->tl_ms);
        DIAG_ADD(parameters, VIRTUAL_START, a->virtual_start);
        return true;
    case LYNRA_TIMER_STAIRWAY:
        DIAG_ADD(parameters, TON_MS, a->t_ms);
        DIAG_ADD(parameters, WARNING_BEFORE_MS, a->warning_before_ms);
        DIAG_ADD(parameters, WARNING_OFF_MS, a->warning_off_ms);
        DIAG_ADD(parameters, RESET_INPUT_INDEX, a->reset_input_index);
        DIAG_ADD(parameters, RETRIGGER, a->retrigger);
        return true;
    case LYNRA_TIMER_MULTI_FUNCTION:
        DIAG_ADD(parameters, TON_MS, a->t_ms);
        DIAG_ADD(parameters, TL_MS, a->tl_ms);
        DIAG_ADD(parameters, WARNING_BEFORE_MS, a->warning_before_ms);
        DIAG_ADD(parameters, WARNING_OFF_MS, a->warning_off_ms);
        return true;
    case LYNRA_TIMER_STOPWATCH:
        DIAG_ADD(parameters, TON_MS, a->t_ms);
        DIAG_ADD(parameters, VIRTUAL_START, a->virtual_start);
        DIAG_ADD(parameters, STOPWATCH_TIME_BASE, a->stopwatch_time_base);
        DIAG_ADD(parameters, RESET_INPUT_INDEX, a->reset_input_index);
        return true;
    case LYNRA_COUNTER_UP_DOWN:
        DIAG_ADD(parameters, COUNTER_INPUT_INDEX, a->counter_input_index);
        DIAG_ADD(parameters, DIRECTION_INPUT_INDEX, a->direction_input_index);
        DIAG_ADD(parameters, RESET_INPUT_INDEX, a->reset_input_index);
        DIAG_ADD(parameters, COUNTER_START_VALUE, a->counter_start_value);
        DIAG_ADD(parameters, COUNTER_ON, a->counter_on);
        DIAG_ADD(parameters, COUNTER_OFF, a->counter_off);
        return true;
    case LYNRA_COUNTER_HOURS:
        DIAG_ADD(parameters, HOURS_ENABLE_INPUT_INDEX, a->hours_enable_input_index);
        DIAG_ADD(parameters, RESET_INPUT_INDEX, a->reset_input_index);
        DIAG_ADD(parameters, HOURS_RESET_ALL_INPUT_INDEX, a->hours_reset_all_input_index);
        DIAG_ADD(parameters, HOURS_TARGET_MS, diag_u64(a->hours_target_ms));
        return true;
    case LYNRA_THRESHOLD_TRIGGER:
        DIAG_ADD(parameters, THRESHOLD_INPUT_INDEX, a->threshold_input_index);
        DIAG_ADD(parameters, THRESHOLD_GATE_MS, a->threshold_gate_ms);
        DIAG_ADD(parameters, THRESHOLD_ON, a->threshold_on);
        DIAG_ADD(parameters, THRESHOLD_OFF, a->threshold_off);
        return true;
    case LYNRA_CMD_WAIT:
        DIAG_ADD(parameters, TON_MS, a->t_ms);
        return true;
    case LYNRA_CMD_FOLLOW:
    case LYNRA_CMD_SET:
    case LYNRA_CMD_RESET:
        return true;
    default: return false;
    }
}

bool lynra_plc_get_values(const LynraPlcEngine *e, size_t ri, size_t ai,
                          LynraValues *values) {
    if (!e || !e->in_use || !values || ri >= e->count ||
        ai >= e->rules[ri].action_count) return false;
    const LynraAction *a = &e->rules[ri].actions[ai];
    const TimerState *s = &e->timers[ri][ai];
    uint64_t elapsed = 0;
    values->count = 0;
    if (s->started && e->has_last_scan && e->last_scan >= s->started_at)
        elapsed = e->last_scan - s->started_at;
    switch (a->type) {
    case LYNRA_TIMER_ON_OFF_DELAY:
        DIAG_ADD(values, ELAPSED_MS, diag_u64(elapsed));
        break;
    case LYNRA_TIMER_STOPWATCH: {
        uint64_t total = s->elapsed_ms;
        if (s->started && e->has_last_scan)
            total = UINT64_MAX - total < elapsed ? UINT64_MAX : total + elapsed;
        DIAG_ADD(values, ELAPSED_MS, diag_u64(total));
        break;
    }
    case LYNRA_TIMER_WIPING_RELAY:
    case LYNRA_TIMER_EDGE_WIPING_RELAY:
    case LYNRA_TIMER_ASYNC_PULSE:
    case LYNRA_TIMER_STAIRWAY:
    case LYNRA_TIMER_MULTI_FUNCTION:
        DIAG_ADD(values, ELAPSED_MS, diag_u64(elapsed));
        break;
    case LYNRA_TIMER_RANDOM_GENERATOR:
        DIAG_ADD(values, RANDOM_PENDING, s->random_pending);
        DIAG_ADD(values, REMAINING_MS,
                 s->random_pending && e->has_last_scan && s->random_due_ms > e->last_scan
                 ? diag_u64(s->random_due_ms - e->last_scan) : 0);
        break;
    case LYNRA_COUNTER_UP_DOWN:
        DIAG_ADD(values, COUNTER_VALUE, s->counter_value);
        break;
    case LYNRA_COUNTER_HOURS:
        DIAG_ADD(values, HOURS_ELAPSED_MS, diag_u64(s->hours_elapsed_ms));
        DIAG_ADD(values, HOURS_TOTAL_MS, diag_u64(s->hours_total_ms));
        break;
    case LYNRA_THRESHOLD_TRIGGER:
        DIAG_ADD(values, THRESHOLD_LAST_COUNT, s->threshold_last_count);
        DIAG_ADD(values, PULSE_COUNT, s->threshold_count);
        break;
    case LYNRA_CMD_WAIT:
    case LYNRA_CMD_FOLLOW:
    case LYNRA_CMD_SET:
    case LYNRA_CMD_RESET:
        DIAG_ADD(values, EXECUTION_STATE, e->cmd_running[ri] ? LYNRA_EXEC_RUNNING :
                 e->cmd_pc[ri] >= e->rules[ri].action_count ? LYNRA_EXEC_COMPLETED : LYNRA_EXEC_IDLE);
        return true;
    default: return false;
    }
    DIAG_ADD(values, EXECUTION_STATE, s->execution_state);
    /* This is the aggregate physical output bit, not a per-action arbitration result. */
    DIAG_ADD(values, OUTPUT_STATE, (e->outputs >> (a->output_index - 1)) & 1u);
    if (a->type == LYNRA_TIMER_MULTI_FUNCTION)
        DIAG_ADD(values, MULTI_PERMANENT, s->multi_permanent);
    return true;
}
#undef DIAG_ADD

bool lynra_plc_get_field(
    const LynraPlcEngine *e,
    size_t rule_index,
    size_t action_index,
    LynraFieldId field,
    LynraFieldValue *value)
{
    if (!e || !e->in_use || !value ||
        rule_index >= e->count)
        return false;

    const LynraRule *r = &e->rules[rule_index];

    if (action_index >= r->action_count)
        return false;

    const LynraAction *a = &r->actions[action_index];
    switch (field) {
			case LYNRA_FIELD_INPUT:
    if (r->condition_count != 1)
        return false;

    *value = r->conditions[0].input_index;
    return true;

case LYNRA_FIELD_TRIGGER_MODE:
    if (r->condition_count != 1)
        return false;

    *value = r->conditions[0].trigger;
    return true;
        case LYNRA_FIELD_OUTPUT:
            *value = (e->outputs >> (a->output_index - 1)) & 1u;
            return true;

        default:
            return false;
    }
}
bool lynra_plc_set_field(LynraPlcEngine *e, size_t ri, size_t ai,
                         LynraFieldId field, LynraFieldValue value) {
    if (!e || !e->in_use || ri >= e->count || ai >= e->rules[ri].action_count)
        return false;
    LynraAction *a = &e->rules[ri].actions[ai];
    LynraAction next = *a;
    switch (field) {
    case LYNRA_FIELD_VIRTUAL_START:
        if ((a->type < LYNRA_TIMER_WIPING_RELAY ||
             (a->type > LYNRA_TIMER_RANDOM_GENERATOR && a->type != LYNRA_TIMER_STOPWATCH)) || value < 0 || value > 1) return false;
        next.virtual_start = (uint8_t)value;
        break;
    case LYNRA_FIELD_TON_MS:
        if ((a->type != LYNRA_TIMER_WIPING_RELAY && a->type != LYNRA_TIMER_STAIRWAY && a->type != LYNRA_TIMER_MULTI_FUNCTION && a->type != LYNRA_TIMER_STOPWATCH) || value < 0 || value > UINT32_MAX) return false;
        next.t_ms = (uint32_t)value;
        break;
    case LYNRA_FIELD_TH_MS:
        if ((a->type != LYNRA_TIMER_ON_OFF_DELAY && a->type != LYNRA_TIMER_EDGE_WIPING_RELAY && a->type != LYNRA_TIMER_ASYNC_PULSE && a->type != LYNRA_TIMER_RANDOM_GENERATOR) || value < 0 || value > UINT32_MAX) return false;
        next.th_ms = (uint32_t)value;
        break;
    case LYNRA_FIELD_TL_MS:
        if ((a->type != LYNRA_TIMER_ON_OFF_DELAY && a->type != LYNRA_TIMER_EDGE_WIPING_RELAY && a->type != LYNRA_TIMER_ASYNC_PULSE && a->type != LYNRA_TIMER_RANDOM_GENERATOR && a->type != LYNRA_TIMER_MULTI_FUNCTION) || value < 0 || value > UINT32_MAX) return false;
        next.tl_ms = (uint32_t)value;
        break;
    case LYNRA_FIELD_TH_RANDOM:
        if ((a->type != LYNRA_TIMER_ON_OFF_DELAY && a->type != LYNRA_TIMER_EDGE_WIPING_RELAY) || value < 0 || value > 1) return false;
        next.th_random = (uint8_t)value;
        break;
    case LYNRA_FIELD_TL_RANDOM:
        if ((a->type != LYNRA_TIMER_ON_OFF_DELAY && a->type != LYNRA_TIMER_EDGE_WIPING_RELAY) || value < 0 || value > 1) return false;
        next.tl_random = (uint8_t)value;
        break;
    case LYNRA_FIELD_PULSE_COUNT:
        if ((a->type != LYNRA_TIMER_EDGE_WIPING_RELAY) || value < 0 || value > 255) return false;
        next.n = (uint8_t)value;
        break;
    case LYNRA_FIELD_WARNING_BEFORE_MS:
        if ((a->type != LYNRA_TIMER_STAIRWAY && a->type != LYNRA_TIMER_MULTI_FUNCTION) || value < 0 || value > UINT32_MAX) return false;
        next.warning_before_ms = (uint32_t)value;
        break;
    case LYNRA_FIELD_WARNING_OFF_MS:
        if ((a->type != LYNRA_TIMER_STAIRWAY && a->type != LYNRA_TIMER_MULTI_FUNCTION) || value < 0 || value > UINT32_MAX) return false;
        next.warning_off_ms = (uint32_t)value;
        break;
    case LYNRA_FIELD_REPEAT:
        if ((a->type != LYNRA_TIMER_EDGE_WIPING_RELAY) || value < 0 || value > 255) return false;
        next.repeat = (uint8_t)value;
        break;
    case LYNRA_FIELD_RETRIGGER:
        if ((a->type != LYNRA_TIMER_ON_OFF_DELAY && a->type != LYNRA_TIMER_EDGE_WIPING_RELAY && a->type != LYNRA_TIMER_STAIRWAY) || value < 0 || value > 255) return false;
        next.retrigger = (uint8_t)value;
        break;
    case LYNRA_FIELD_STOPWATCH_TIME_BASE:
        if ((a->type != LYNRA_TIMER_STOPWATCH) || value < 0 || value > 255) return false;
        next.stopwatch_time_base = (uint8_t)value;
        break;
    case LYNRA_FIELD_COUNTER_START_VALUE:
        if ((a->type != LYNRA_COUNTER_UP_DOWN) || value < INT32_MIN || value > INT32_MAX) return false;
        next.counter_start_value = (int32_t)value;
        break;
    case LYNRA_FIELD_COUNTER_ON:
        if ((a->type != LYNRA_COUNTER_UP_DOWN) || value < INT32_MIN || value > INT32_MAX) return false;
        next.counter_on = (int32_t)value;
        break;
    case LYNRA_FIELD_COUNTER_OFF:
        if ((a->type != LYNRA_COUNTER_UP_DOWN) || value < INT32_MIN || value > INT32_MAX) return false;
        next.counter_off = (int32_t)value;
        break;
    case LYNRA_FIELD_HOURS_TARGET_MS:
        if ((a->type != LYNRA_COUNTER_HOURS) || value < 0 || value > INT64_MAX) return false;
        next.hours_target_ms = (uint64_t)value;
        break;
    case LYNRA_FIELD_THRESHOLD_GATE_MS:
        if ((a->type != LYNRA_THRESHOLD_TRIGGER) || value < 0 || value > UINT32_MAX) return false;
        next.threshold_gate_ms = (uint32_t)value;
        break;
    case LYNRA_FIELD_THRESHOLD_ON:
        if ((a->type != LYNRA_THRESHOLD_TRIGGER) || value < 0 || value > UINT32_MAX) return false;
        next.threshold_on = (uint32_t)value;
        break;
    case LYNRA_FIELD_THRESHOLD_OFF:
        if ((a->type != LYNRA_THRESHOLD_TRIGGER) || value < 0 || value > UINT32_MAX) return false;
        next.threshold_off = (uint32_t)value;
        break;
    default: return false; /* Wiring, live values and unknown IDs are immutable. */
    }
    /* Validate cross-parameter constraints before committing the update. */
    switch (next.type) {
    case LYNRA_TIMER_EDGE_WIPING_RELAY:
        if (!next.n || !next.th_ms || !next.tl_ms || next.repeat > 1 || next.retrigger > 1) return false;
        break;
    case LYNRA_TIMER_ASYNC_PULSE:
        if (!next.th_ms || !next.tl_ms) return false;
        break;
    case LYNRA_TIMER_STAIRWAY:
        if (!next.t_ms || next.warning_before_ms > next.t_ms ||
            next.warning_off_ms > next.warning_before_ms || next.retrigger > 1) return false;
        break;
    case LYNRA_TIMER_MULTI_FUNCTION:
        if (!next.t_ms || !next.tl_ms || next.warning_before_ms > next.t_ms ||
            next.warning_off_ms > next.warning_before_ms) return false;
        break;
    case LYNRA_TIMER_STOPWATCH:
        if (next.stopwatch_time_base > 2) return false;
        break;
    case LYNRA_THRESHOLD_TRIGGER:
        if (next.threshold_gate_ms < 1000 || next.threshold_gate_ms > 100000 ||
            next.threshold_on > 9999 || next.threshold_off > 9999) return false;
        break;
    default: break;
    }
    *a = next;
    return true;
}
bool lynra_plc_set_parameter(
    LynraPlcEngine *e,
    size_t rule_index,
    size_t action_index,
    LynraFieldId parameter,
    LynraFieldValue value)
{
    return lynra_plc_set_field(
        e, rule_index, action_index, parameter, value);
}